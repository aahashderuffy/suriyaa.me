# Login

<a href="http://bit.ly/1b8xZhI" target="_blank"><img src="http://labs.williamsyms.com/login_v2/loginv2.png"></a>

Simple sleek looking login, feel free to contribute. [Demo](http://bit.ly/1b8xZhI)

## Browser support

The project is tested in Chrome and Firefox. It should work in the current stable releases of Chrome, Firefox, Safari as well as IE7 and up.

<img src="https://raw.github.com/paulirish/browser-logos/master/main-desktop.png">

## Latest Releases

#### [0.2.2](https://github.com/wsyms/login/releases/tag/0.2.2)

## License

GPL v3 licensed

Copyright (C) 2014 William Syms, [http://williamsyms.com](http://williamsyms.com)
